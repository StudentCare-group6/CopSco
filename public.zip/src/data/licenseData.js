export default [
    {
        id: 1,
        status:"Active",
        name: "D.D Rathnayake", 
        img: "police.jpg"   
    }
]