export default [
    {
        id: 1,
        name: "D.D Rathnayake", 
        img: "police.jpg"   
    }
]