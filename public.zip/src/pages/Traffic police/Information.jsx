import * as React from 'react';


export default function Information() {
    return (
        <div>
            <h1>Information</h1>
        </div>
    );
}