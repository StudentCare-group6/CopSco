import * as React from 'react';


export default function Notifications() {
    return (
        <div>
            <h1>Notifications</h1>
        </div>
    );
}