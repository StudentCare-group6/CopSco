import * as React from 'react';


export default function Statistics() {
    return (
        <div>
            <h1>Statistics</h1>
        </div>
    );
}